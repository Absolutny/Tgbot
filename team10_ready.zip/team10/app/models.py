from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from .extensions import db


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255))
    bio = db.Column(db.Text, default='')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return bool(self.password_hash) and check_password_hash(self.password_hash, password)

    def public_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'bio': self.bio or '',
            'created_at': self.created_at.isoformat() + 'Z' if self.created_at else None,
        }


class Channel(db.Model):
    """Публичный канал: виден всем, писать могут участники."""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True, nullable=False)
    description = db.Column(db.String(500), default='')
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description or '',
            'created_by': self.created_by,
            'created_at': self.created_at.isoformat() + 'Z',
        }


class ChannelMember(db.Model):
    channel_id = db.Column(db.Integer, db.ForeignKey('channel.id'), primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), primary_key=True, index=True)
    joined_at = db.Column(db.DateTime, default=datetime.utcnow)


class Chat(db.Model):
    """Приватный чат двух пользователей (user_a_id < user_b_id)."""
    __table_args__ = (db.UniqueConstraint('user_a_id', 'user_b_id'),)
    id = db.Column(db.Integer, primary_key=True)
    user_a_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    user_b_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def has_member(self, user_id):
        return user_id in (self.user_a_id, self.user_b_id)

    def to_dict(self):
        return {
            'id': self.id,
            'user_a_id': self.user_a_id,
            'user_b_id': self.user_b_id,
            'created_at': self.created_at.isoformat() + 'Z',
        }


class Message(db.Model):
    __table_args__ = (
        db.Index('ix_message_channel_id_id', 'channel_id', 'id'),
        db.Index('ix_message_chat_id_id', 'chat_id', 'id'),
        db.CheckConstraint('(channel_id IS NULL) != (chat_id IS NULL)'),
    )
    id = db.Column(db.Integer, primary_key=True)
    channel_id = db.Column(db.Integer, db.ForeignKey('channel.id'), nullable=True)
    chat_id = db.Column(db.Integer, db.ForeignKey('chat.id'), nullable=True)
    author_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    text = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'channel_id': self.channel_id,
            'chat_id': self.chat_id,
            'author_id': self.author_id,
            'text': self.text,
            'created_at': self.created_at.isoformat() + 'Z',
        }
