import csv
import io
import time
from collections import defaultdict, deque
from functools import wraps

from flask import Blueprint, jsonify, current_app, request, session, g, Response
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from sqlalchemy import or_, select
from sqlalchemy.exc import IntegrityError

from .extensions import db
from .models import User, Channel, ChannelMember, Chat, Message

bp = Blueprint('api', __name__)

MAX_MESSAGE = 4000
MAX_PAGE = 100
TOKEN_TTL = 7 * 24 * 3600


# ---------- helpers ----------
def err(status, message):
    return jsonify({'error': message}), status


@bp.errorhandler(404)
def _404(e):
    return err(404, 'not found')


@bp.errorhandler(405)
def _405(e):
    return err(405, 'method not allowed')


def _serializer():
    return URLSafeTimedSerializer(current_app.config['SECRET_KEY'], salt='api-token')


def make_token(user_id):
    return _serializer().dumps({'uid': user_id})


def current_user():
    if hasattr(g, '_user'):
        return g._user
    user = None
    auth = request.headers.get('Authorization', '')
    if auth.startswith('Bearer '):
        try:
            data = _serializer().loads(auth[7:].strip(), max_age=TOKEN_TTL)
            user = db.session.get(User, data.get('uid'))
        except (BadSignature, SignatureExpired, AttributeError):
            user = None
    elif session.get('user_id'):
        user = db.session.get(User, session['user_id'])
    g._user = user
    return user


def login_required(f):
    @wraps(f)
    def wrapper(*a, **kw):
        if not current_user():
            return err(401, 'authentication required')
        return f(*a, **kw)
    return wrapper


def json_body():
    """Мутирующие запросы принимаем только как JSON (защита от CSRF через формы)."""
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return None
    return data


def paging():
    try:
        limit = int(request.args.get('limit', 50))
        offset = int(request.args.get('offset', 0))
    except ValueError:
        limit, offset = 50, 0
    return max(1, min(limit, MAX_PAGE)), max(0, offset)


def like_escape(s):
    return s.replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_')


# простой rate limit для логина/регистрации (по IP)
_hits = defaultdict(deque)


def rate_limited(key, limit=20, window=60):
    now = time.time()
    q = _hits[key]
    while q and q[0] < now - window:
        q.popleft()
    if len(q) >= limit:
        return True
    q.append(now)
    return False


@bp.after_request
def _headers(resp):
    resp.headers['X-Content-Type-Options'] = 'nosniff'
    resp.headers['Cache-Control'] = 'no-store'
    return resp


# ---------- health ----------
@bp.get('/health')
def health():
    return jsonify({
        'status': 'ok',
        'team_id': current_app.config['TEAM_ID'],
        'team_name': current_app.config['TEAM_NAME'],
    })


# ---------- auth ----------
def _creds(data):
    username = data.get('username')
    password = data.get('password')
    if not isinstance(username, str) or not isinstance(password, str):
        return None, None
    return username.strip(), password


@bp.post('/auth/register')
def api_register():
    if rate_limited('reg:' + (request.remote_addr or '')):
        return err(429, 'too many requests')
    data = json_body()
    if data is None:
        return err(400, 'JSON body required')
    username, password = _creds(data)
    if not username or not password:
        return err(400, 'username and password required')
    if len(username) > 80 or len(password) < 6 or len(password) > 200:
        return err(400, 'invalid username or password length (password 6-200)')
    user = User(username=username)
    user.set_password(password)
    db.session.add(user)
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return err(409, 'user already exists')
    return jsonify(user.public_dict()), 201


@bp.post('/auth/login')
def api_login():
    if rate_limited('login:' + (request.remote_addr or ''), limit=30):
        return err(429, 'too many requests')
    data = json_body()
    if data is None:
        return err(400, 'JSON body required')
    username, password = _creds(data)
    if not username or not password:
        return err(400, 'username and password required')
    user = User.query.filter_by(username=username).first()
    if not user or not user.check_password(password):
        return err(401, 'invalid credentials')
    session.clear()
    session['user_id'] = user.id
    return jsonify({'token': make_token(user.id), 'user': user.public_dict()})


@bp.post('/auth/logout')
def api_logout():
    session.clear()
    return jsonify({'status': 'ok'})


@bp.get('/auth/me')
@login_required
def me():
    return jsonify(current_user().public_dict())


# ---------- users / public profile ----------
@bp.get('/users')
@login_required
def list_users():
    limit, offset = paging()
    q = User.query
    s = request.args.get('q', '').strip()
    if s:
        q = q.filter(User.username.like('%' + like_escape(s[:80]) + '%', escape='\\'))
    users = q.order_by(User.id).limit(limit).offset(offset).all()
    return jsonify([u.public_dict() for u in users])


@bp.get('/users/<int:user_id>')
def get_profile(user_id):
    user = db.session.get(User, user_id)
    if not user:
        return err(404, 'user not found')
    data = user.public_dict()
    data['channels_count'] = ChannelMember.query.filter_by(user_id=user_id).count()
    return jsonify(data)


@bp.patch('/users/me')
@login_required
def update_profile():
    data = json_body()
    if data is None:
        return err(400, 'JSON body required')
    bio = data.get('bio')
    if not isinstance(bio, str) or len(bio) > 1000:
        return err(400, 'bio must be a string up to 1000 chars')
    user = current_user()
    user.bio = bio
    db.session.commit()
    return jsonify(user.public_dict())


# ---------- channels (public) ----------
@bp.get('/channels')
def list_channels():
    limit, offset = paging()
    q = Channel.query
    s = request.args.get('q', '').strip()
    if s:
        q = q.filter(Channel.name.like('%' + like_escape(s[:64]) + '%', escape='\\'))
    chans = q.order_by(Channel.id).limit(limit).offset(offset).all()
    return jsonify([c.to_dict() for c in chans])


@bp.post('/channels')
@login_required
def create_channel():
    data = json_body()
    if data is None:
        return err(400, 'JSON body required')
    name = data.get('name')
    desc = data.get('description', '')
    if not isinstance(name, str) or not name.strip() or len(name.strip()) > 64:
        return err(400, 'name required (max 64)')
    if not isinstance(desc, str) or len(desc) > 500:
        return err(400, 'description max 500')
    user = current_user()
    ch = Channel(name=name.strip(), description=desc, created_by=user.id)
    db.session.add(ch)
    try:
        db.session.flush()
        db.session.add(ChannelMember(channel_id=ch.id, user_id=user.id))
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return err(409, 'channel already exists')
    return jsonify(ch.to_dict()), 201


@bp.get('/channels/<int:channel_id>')
def get_channel(channel_id):
    ch = db.session.get(Channel, channel_id)
    if not ch:
        return err(404, 'channel not found')
    d = ch.to_dict()
    d['members_count'] = ChannelMember.query.filter_by(channel_id=channel_id).count()
    return jsonify(d)


@bp.post('/channels/<int:channel_id>/join')
@login_required
def join_channel(channel_id):
    if not db.session.get(Channel, channel_id):
        return err(404, 'channel not found')
    uid = current_user().id
    if not db.session.get(ChannelMember, (channel_id, uid)):
        db.session.add(ChannelMember(channel_id=channel_id, user_id=uid))
        try:
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
    return jsonify({'status': 'joined'})


@bp.post('/channels/<int:channel_id>/leave')
@login_required
def leave_channel(channel_id):
    m = db.session.get(ChannelMember, (channel_id, current_user().id))
    if m:
        db.session.delete(m)
        db.session.commit()
    return jsonify({'status': 'left'})


def _validate_text(data):
    text = data.get('text') if data else None
    if not isinstance(text, str) or not text.strip():
        return None, err(400, 'text required')
    if len(text) > MAX_MESSAGE:
        return None, err(400, f'text max {MAX_MESSAGE} chars')
    return text, None


@bp.get('/channels/<int:channel_id>/messages')
def channel_messages(channel_id):
    if not db.session.get(Channel, channel_id):
        return err(404, 'channel not found')
    limit, offset = paging()
    q = Message.query.filter_by(channel_id=channel_id)
    before = request.args.get('before_id', type=int)
    if before:
        q = q.filter(Message.id < before)
    msgs = q.order_by(Message.id.desc()).limit(limit).offset(offset).all()
    return jsonify([m.to_dict() for m in msgs])


@bp.post('/channels/<int:channel_id>/messages')
@login_required
def post_channel_message(channel_id):
    if not db.session.get(Channel, channel_id):
        return err(404, 'channel not found')
    uid = current_user().id
    if not db.session.get(ChannelMember, (channel_id, uid)):
        return err(403, 'join the channel first')
    text, e = _validate_text(json_body())
    if e:
        return e
    m = Message(channel_id=channel_id, author_id=uid, text=text)
    db.session.add(m)
    db.session.commit()
    return jsonify(m.to_dict()), 201


# ---------- private chats ----------
def _get_chat_or_error(chat_id):
    chat = db.session.get(Chat, chat_id)
    # одинаковый ответ для несуществующего и чужого чата — не раскрываем существование
    if not chat or not chat.has_member(current_user().id):
        return None, err(404, 'chat not found')
    return chat, None


@bp.get('/chats')
@login_required
def list_chats():
    uid = current_user().id
    chats = Chat.query.filter(or_(Chat.user_a_id == uid, Chat.user_b_id == uid)) \
        .order_by(Chat.id).all()
    return jsonify([c.to_dict() for c in chats])


@bp.post('/chats')
@login_required
def create_chat():
    data = json_body()
    if data is None:
        return err(400, 'JSON body required')
    other = data.get('user_id')
    if not isinstance(other, int) or isinstance(other, bool):
        return err(400, 'user_id (int) required')
    uid = current_user().id
    if other == uid:
        return err(400, 'cannot chat with yourself')
    if not db.session.get(User, other):
        return err(404, 'user not found')
    a, b = sorted((uid, other))
    chat = Chat.query.filter_by(user_a_id=a, user_b_id=b).first()
    if chat:
        return jsonify(chat.to_dict()), 200
    chat = Chat(user_a_id=a, user_b_id=b)
    db.session.add(chat)
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        chat = Chat.query.filter_by(user_a_id=a, user_b_id=b).first()
        return jsonify(chat.to_dict()), 200
    return jsonify(chat.to_dict()), 201


@bp.get('/chats/<int:chat_id>/messages')
@login_required
def chat_messages(chat_id):
    chat, e = _get_chat_or_error(chat_id)
    if e:
        return e
    limit, offset = paging()
    q = Message.query.filter_by(chat_id=chat.id)
    before = request.args.get('before_id', type=int)
    if before:
        q = q.filter(Message.id < before)
    msgs = q.order_by(Message.id.desc()).limit(limit).offset(offset).all()
    return jsonify([m.to_dict() for m in msgs])


@bp.post('/chats/<int:chat_id>/messages')
@login_required
def post_chat_message(chat_id):
    chat, e = _get_chat_or_error(chat_id)
    if e:
        return e
    text, e = _validate_text(json_body())
    if e:
        return e
    m = Message(chat_id=chat.id, author_id=current_user().id, text=text)
    db.session.add(m)
    db.session.commit()
    return jsonify(m.to_dict()), 201


# ---------- search ----------
@bp.get('/search')
@login_required
def search():
    s = request.args.get('q', '').strip()
    if not s:
        return err(400, 'q required')
    if len(s) > 100:
        return err(400, 'q too long')
    limit, offset = paging()
    uid = current_user().id
    my_chats = select(Chat.id).where(or_(Chat.user_a_id == uid, Chat.user_b_id == uid))
    pattern = '%' + like_escape(s) + '%'
    # только публичные каналы + свои приватные чаты
    q = Message.query.filter(
        Message.text.like(pattern, escape='\\'),
        or_(Message.channel_id.isnot(None), Message.chat_id.in_(my_chats)),
    )
    msgs = q.order_by(Message.id.desc()).limit(limit).offset(offset).all()
    return jsonify([m.to_dict() for m in msgs])


# ---------- export ----------
def _csv_safe(v):
    v = str(v)
    if v and v[0] in '=+-@\t\r':
        return "'" + v
    return v


def _export(messages, fmt, filename):
    if fmt == 'csv':
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(['id', 'channel_id', 'chat_id', 'author_id', 'text', 'created_at'])
        for m in messages:
            w.writerow([m.id, m.channel_id or '', m.chat_id or '', m.author_id,
                        _csv_safe(m.text), m.created_at.isoformat() + 'Z'])
        return Response(buf.getvalue(), mimetype='text/csv', headers={
            'Content-Disposition': f'attachment; filename="{filename}.csv"'})
    resp = jsonify([m.to_dict() for m in messages])
    resp.headers['Content-Disposition'] = f'attachment; filename="{filename}.json"'
    return resp


@bp.get('/channels/<int:channel_id>/export')
@login_required
def export_channel(channel_id):
    if not db.session.get(Channel, channel_id):
        return err(404, 'channel not found')
    msgs = Message.query.filter_by(channel_id=channel_id).order_by(Message.id).limit(10000).all()
    return _export(msgs, request.args.get('format', 'json'), f'channel_{channel_id}')


@bp.get('/chats/<int:chat_id>/export')
@login_required
def export_chat(chat_id):
    chat, e = _get_chat_or_error(chat_id)
    if e:
        return e
    msgs = Message.query.filter_by(chat_id=chat.id).order_by(Message.id).limit(10000).all()
    return _export(msgs, request.args.get('format', 'json'), f'chat_{chat_id}')
